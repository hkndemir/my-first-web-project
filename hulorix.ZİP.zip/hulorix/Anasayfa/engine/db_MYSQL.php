<?php
ini_set('display_errors','0');
error_reporting(0);


class MYSQL_DB extends DB
{
    function ValidControl($data, $column, $table)
    {
        $q = "SELECT * FROM ".$table." WHERE ".$column." = :data";
        $p = array("data" => $data);
        $rows = $this->query($q, $p);
        if (count($rows) > 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    public function get_MinusProductList()
    {
        $q = "SELECT product.id, product.name, product.note, category.name as 'category', supply.company as 'supply', product.barcode, units.name as 'unit', product.stock, product.alis, product.satis, product.crit, product.active FROM `product` INNER JOIN category on category.id = product.category INNER JOIN supply on supply.id = product.supply INNER JOIN units on units.id = product.unit and product.stock <= product.crit";
        $p = "";
        return $this->query($q, $p);
    }
    public function Get_ColSup($mode, $time1, $time2)
    {
        if ($mode == "All")
        {
            $sum = $this->single("Select Sum(balance) From s_payment Where time BETWEEN :date1 and :date2", array("date1" => $time1, "date2" => $time2));
        }
        else $sum = $this->single("Select Sum(balance) From s_payment Where cash=:cash and time BETWEEN :date1 and :date2", array("date1" => $time1, "date2" => $time2, "cash" => $mode));
        if ($sum == null)
        {
            return "0.00";
        }
        else return $sum;
    }
    public function Get_ColCus($mode, $time1, $time2)
    {
        if ($mode == "All")
        {
            $sum = $this->single("Select Sum(balance) From c_payment Where time > :date1 and time < :date2", array("date1" => $time1, "date2" => $time2));
        }
        else $sum = $this->single("Select Sum(balance) From c_payment Where cash=:cash and time > :date1 and time < :date2", array("date1" => $time1, "date2" => $time2, "cash" => $mode));
        if ($sum == null)
        {
            return "0.00";
        }
        else return $sum;
    }
    public function Get_Sum($mode, $time1, $time2)
    {
        if ($mode == "All")
        {
            $sum = $this->single("Select Sum(balance) From sales Where time > :date1 and time < :date2", array("date1" => $time1, "date2" => $time2));
        }
        else $sum = $this->single("Select Sum(balance) From sales Where cash=:cash and time > :date1 and time < :date2", array("date1" => $time1, "date2" => $time2, "cash" => $mode));
        if ($sum == null)
        {
            return "0.00";
        }
        else return $sum;
    }
    public function Get_SumSup($mode, $time1, $time2)
    {
        if ($mode == "All")
        {
            $sum = $this->single("Select Sum(balance) From buying Where time > :date1 and time < :date2", array("date1" => $time1, "date2" => $time2));
        }
        else $sum = $this->single("Select Sum(balance) From buying Where cash=:cash and time > :date1 and time < :date2", array("date1" => $time1, "date2" => $time2, "cash" => $mode));
        if ($sum == null)
        {
            return "0.00";
        }
        else return $sum;
    }
    public function Get_Profit($mode, $time1, $time2)
    {
        if ($mode == "All")
        {
            $sum = $this->single("Select Sum(profit) From sales Where time > :date1 and time < :date2", array("date1" => $time1, "date2" => $time2));
        }
        else $sum = $this->single("Select Sum(profit) From sales Where cash=:cash and time > :date1 and time < :date2", array("date1" => $time1, "date2" => $time2, "cash" => $mode));
        if ($sum == null)
        {
            return "0.00";
        }
        else return $sum;
    }
    public function Reg_Customer($name, $note, $phone, $address, $crit, $active)
    {
        $q = "INSERT INTO `customer` (name, note, phone, address, active, crit) VALUES (:name, :note, :phone, :address, :active, :crit)";
        $p = array("name" => $name, "note" => $note, "phone" => $phone, "address" => $address, "active" => $active, "crit" => $crit);
        return $this->query($q, $p);
    }
    public function Reg_Category($name)
    {
        $q = "INSERT INTO `category` (name, active) VALUES (:name, :active)";
        $p = array("name" => $name, "active" => 1);
        return $this->query($q, $p);
    }
    public function Reg_Supply($company, $person)
    {
        $q = "INSERT INTO `supply` (company, person, active) VALUES (:company, :person, :active)";
        $p = array("company" => $company, "person" => $person, "active" => 1);
        return $this->query($q, $p);
    }
    public function Reg_Units($name)
    {
        $q = "INSERT INTO `units` (name, active) VALUES (:name, :active)";
        $p = array("name" => $name, "active" => 1);
        return $this->query($q, $p);
    }
    public function Reg_Product($name, $note, $category, $supply, $barcode, $unit, $alis, $satis, $crit)
    {
        $q = "INSERT INTO `product`(`name`, `note`, `category`, `supply`, `barcode`, `unit`, `alis`, `satis`, `crit`, active) VALUES (:name, :note, :category, :supply, :barcode, :unit, :alis, :satis, :crit, 1)";
        $p = array("name" => $name, "note" => $note, "category" => $category, "supply" => $supply, "barcode" => $barcode, "unit" => $unit, "alis" => $alis, "satis" => $satis, "crit" => $crit);
        return $this->query($q, $p);
    }
    public function Reg_Iade($customer, $balance, $profit, $cash, $type)
    {
        $q = "Insert Into iade (customer, time, balance, profit, cash, type) Values (:customer, :time, :balance, :profit, :cash, :type)";
        $p = array("customer" => $customer, "balance" => $balance, "time" => time(), "cash" => $cash, "profit" => $profit, "type" => $type);
        $this->query($q, $p);
        return $this->query("SELECT * FROM `iade` WHERE id != :id ORDER BY id DESC LIMIT 1", array("id" => 0));
    }
    public function Reg_Sales($customer, $balance, $profit, $cash)
    {
        $q = "Insert Into sales (customer, time, balance, profit, cash) Values (:customer, :time, :balance, :profit, :cash)";
        $p = array("customer" => $customer, "balance" => $balance, "time" => time(), "cash" => $cash, "profit" => $profit);
        $this->query($q, $p);
        return $this->query("SELECT * FROM `sales` WHERE id != :id ORDER BY id DESC LIMIT 1", array("id" => 0));
    }
    public function Reg_Buying($supply, $balance, $cash)
    {
        $q = "Insert Into buying (supply, time, balance, cash) Values (:supply, :time, :balance, :cash)";
        $p = array("supply" => $supply, "balance" => $balance, "time" => time(), "cash" => $cash);
        $this->query($q, $p);
        return $this->query("SELECT * FROM `buying` WHERE id != :id ORDER BY id DESC LIMIT 1", array("id" => 0));
    }
    public function Reg_SalesProd($s_id, $p_id, $amount, $price, $alis)
    {
        $q = "Insert into salesprod (s_id, p_id, amount, price, alis) Values (:s_id, :p_id, :amount, :price, :alis)";
        $p = array("s_id" => $s_id, "p_id" => $p_id, "amount" => $amount, "price" => $price, "alis" => $alis);
        return $this->query($q, $p);
    }
    public function Reg_IadeProd($s_id, $p_id, $amount, $price, $alis)
    {
        $q = "Insert into iadeprod (s_id, p_id, amount, price, alis) Values (:s_id, :p_id, :amount, :price, :alis)";
        $p = array("s_id" => $s_id, "p_id" => $p_id, "amount" => $amount, "price" => $price, "alis" => $alis);
        return $this->query($q, $p);
    }
    public function Reg_BuyingProd($s_id, $p_id, $amount, $last)
    {
        $q = "Insert into buyingprod (b_id, p_id, amount, lastPrice) Values (:s_id, :p_id, :amount, :lastPrice)";
        $p = array("s_id" => $s_id, "p_id" => $p_id, "amount" => $amount, "lastPrice" => $last);
        return $this->query($q, $p);
    }
    public function Reg_C_Collection($c_id, $cash, $balance)
    {
        $h_balance = $this->single("Select debt from customer Where id=:sid", array("sid" => $c_id));
        $q = "Insert into c_payment (c_id, time, cash, balance, h_balance) Values (:c, :time, :cash, :balance, :h_balance)";
        $p = array("c" => $c_id, "time" => time(), "cash" => $cash, "balance" => $balance, "h_balance" => $h_balance);
        return $this->query($q, $p);
    }
    public function Reg_S_Collection($s_id, $cash, $balance)
    {
        $h_balance = $this->single("Select balance from supply Where id=:sid", array("sid" => $s_id));
        $q = "Insert into s_payment (s_id, time, cash, balance, h_balance) Values (:c, :time, :cash, :balance, :h_balance)";
        $p = array("c" => $s_id, "time" => time(), "cash" => $cash, "balance" => $balance, "h_balance" => $h_balance);
        return $this->query($q, $p);
    }
    public function get_cPayment()
    {
        $q = "SELECT c_payment.id, customer.id as 'c_id', customer.name, c_payment.h_balance, cast((c_payment.h_balance - c_payment.balance) as decimal(10,2)) as 'n_balance', c_payment.time, c_payment.cash, c_payment.balance FROM `c_payment` INNER JOIN customer on customer.id = c_payment.c_id Order BY c_payment.time DESC";
        $p = "";
        return $this->query($q, $p);
    }
    public function get_sPayment()
    {
        $q = "SELECT s_payment.id, supply.id as 's_id', supply.company, s_payment.h_balance, cast((s_payment.h_balance - s_payment.balance) as decimal(10,2)) as 'n_balance', s_payment.time, s_payment.cash, s_payment.balance FROM `s_payment` INNER JOIN supply on supply.id = s_payment.s_id Order BY s_payment.time DESC";
        $p = "";
        return $this->query($q, $p);
    }
    public function Update_Customer($name, $note, $phone, $address, $crit, $id)
    {
        $q = "UPDATE `customer` SET name = :name, note = :note, phone = :phone, address = :address, crit = :crit WHERE id=:id";
        $p = array("name" => $name, "note" => $note, "phone" => $phone, "address" => $address, "id" => $id, "crit" => $crit);
        return $this->query($q, $p);
    }
    public function Update_Category($name, $id)
    {
        $q = "Update `category` SET name=:name Where id=:id";
        $p = array("name" => $name, "id" => $id);
        return $this->query($q, $p);
    }
    public function Update_Supply($company, $person, $id)
    {
        $q = "Update `supply` SET company=:company, person=:person Where id=:id";
        $p = array("company" => $company, "person" => $person, "id" => $id);
        return $this->query($q, $p);
    }
    public function Update_Units($name, $id)
    {
        $q = "Update `units` SET name=:name Where id=:id";
        $p = array("name" => $name, "id" => $id);
        return $this->query($q, $p);
    }
    public function Update_Product($name, $note, $category, $supply, $barcode, $unit, $alis, $satis, $crit, $id)
    {
        $q = "UPDATE `product` SET `name`=:name,`note`=:note,`category`=:category,`supply`=:supply, `barcode`=:barcode,`unit`=:unit, `alis`=:alis,`satis`=:satis,`crit`=:crit WHERE id=:id";
        $p = array("name" => $name, "note" => $note, "category" => $category, "supply" => $supply, "barcode" => $barcode, "unit" => $unit, "alis" => $alis, "satis" => $satis, "crit" => $crit, "id" => $id);
        return $this->query($q, $p);
    }
    public function Add_Stock($id, $amount)
    {
        $q = "Update product Set stock = (stock + :amount) Where id=:id";
        $p = array("amount" => $amount, "id" => $id);
        return $this->query($q, $p);
    }
    public function Remove_Stock($id, $amount)
    {
        $q = "Update product Set stock = (stock - :amount) Where id=:id";
        $p = array("amount" => $amount, "id" => $id);
        return $this->query($q, $p);
    }
    public function Add_Debt($id, $debt)
    {
        $q = "Update customer Set debt = (debt + :amount) Where id=:id";
        $p = array("amount" => $debt, "id" => $id);
        return $this->query($q, $p);
    }
    public function Add_Debt_Supply($id, $debt)
    {
        $q = "Update supply Set balance = (balance + :amount) Where id=:id";
        $p = array("amount" => $debt, "id" => $id);
        return $this->query($q, $p);
    }
    public function Remove_Debt($id, $debt)
    {
        $q = "Update customer Set debt = (debt - :amount) Where id=:id";
        $p = array("amount" => $debt, "id" => $id);
        return $this->query($q, $p);
    }
    public function Remove_Debt_Supply($id, $debt)
    {
        $q = "Update supply Set balance = (balance - :amount) Where id=:id";
        $p = array("amount" => $debt, "id" => $id);
        return $this->query($q, $p);
    }
    public function get_Category()
    {
        $q = "SELECT * FROM `category` Order by active DESC";
        $p = "";
        return $this->query($q, $p);
    }
    public function get_CustomerForSales()
    {
        $q = "SELECT * FROM `customer` Where active = 1 Order by debt DESC";
        $p = "";
        return $this->query($q, $p);
    }
    public function get_SupplyForSales()
    {
        $q = "SELECT * FROM `supply` Where active = 1 Order by company ";
        $p = "";
        return $this->query($q, $p);
    }
    public function get_Customer()
    {
        $q = "SELECT * FROM `customer` Where id != 0 Order by active DESC";
        $p = "";
        return $this->query($q, $p);
    }
    public function get_Supply()
    {
        $q = "SELECT * FROM `supply` Order by active DESC";
        $p = "";
        return $this->query($q, $p);
    }
    public function get_ProductList()
    {
        $q = "SELECT product.id, product.name, product.note, category.name as 'category', supply.company as 'supply', product.barcode, units.name as 'unit', product.stock, product.alis, product.satis, product.crit, product.active FROM `product` INNER JOIN category on category.id = product.category INNER JOIN supply on supply.id = product.supply INNER JOIN units on units.id = product.unit";
        $p = "";
        return $this->query($q, $p);
    }
    public function get_Units()
    {
        $q = "SELECT * FROM `units` Order by active DESC";
        $p = "";
        return $this->query($q, $p);
    }

    //------------------CONVERT-----------------------
    public function ConvertDatetimeToTimestamp($time)
    {
        date_default_timezone_set('Europe/Istanbul');
        $veri = explode(" ", $time);
        $aylar = array("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim","Kasım","Aralık");
        $ay = 0;
        for ($i = 0; $i < count($aylar); $i++)
        {
            if($aylar[$i] == $veri[2])
            {
                $ay = $i + 1;
            }
        }
        return mktime("00", "00", "00", "$ay", "$veri[1]", "$veri[3]");
    }
    public function ConvertTimestampToDatetime($timestamp)
    {
        date_default_timezone_set('Europe/Istanbul');
        $month = date("F", $timestamp);
        $day = date("l", $timestamp);
        $dayN = date("d", $timestamp);
        $year = date("Y", $timestamp);
        $hours = date("H", $timestamp);
        $min = date("i", $timestamp);
        $aylarE = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        $gunlerE = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
        $aylarT = array("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim","Kasım","Aralık");
        $gunlerT = array("Pazartes", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar");
        for ($i = 0; $i < count($aylarE); $i++)
        {
            if ($aylarE[$i] == $month)
            {
                $month = $aylarT[$i];
                break;
            }
        }
        for ($i = 0; $i < count($gunlerE); $i++)
        {
            if ($gunlerE[$i] == $day)
            {
                $day = $gunlerT[$i];
                break;
            }
        }
        return $dayN." ".$month." ".$day." ".$year." - ".$hours.":".$min;
    }
    //------------------CONVERT-----------------------

}
$database = new MYSQL_DB();

