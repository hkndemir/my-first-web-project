<?php
header('Content-Type: text/html; charset=UTF-8');

set_time_limit(0);
//error_reporting(E_ALL ^ E_NOTICE);

date_default_timezone_set('Europe/Istanbul');

define("SQL_SERVER", "localhost");

// ***** Database Username
define("SQL_USER", "root");

// ***** Database Password
define("SQL_PASS", "");

// ***** Database Name
define("SQL_DB", "hulorix");
?>
