<?php

ob_start();
session_start();


 //error_reporting(0);
 date_default_timezone_set('Europe/Istanbul');
 header("Access-Control-Allow-Origin: *");

       
 if(isset($_POST['isset'])){
    include("Database.php");
     switch($_POST['isset']){
        case "addToBasket":           
            $id = $_POST['ide'];
            $boll = false;
            $index;
            $kont=$_SESSION['urunler'];
            for($i=0; $i<count($kont);$i++){
                if($id==$kont[$i]["ide"]){
                    $boll = true;
                    $index = $i;
                }
            }
            if($boll){
                $kont[$index]['adet'] += 1;
                $_SESSION['urunler'] = $kont;
            }
            else{
             $veri = $database->row("Select isim,resim, satis From urunler Where ide= :id", array("id" => $id));
             $image=$veri['resim'];
             $isim=$veri['isim'];
             $fiyat=$veri['satis'];
             $adet=1;
             $urun =array( "ide"=>$id,"image"=>$image,"name"=>$isim,"fee"=>$fiyat,"adet"=>$adet);
             print_r($urun);
             $_SESSION['urunler'] [] = $urun;
            }
        break;  
        case "FlushBasket":
            $_SESSION['urunler'] = "";
        break;   
        case "AddAmount":
            $id = $_POST['id'];
            $adet = $_POST['amount'];
            $kont=$_SESSION['urunler'];
            $index;
            for($i=0; $i<count($kont);$i++){
                if($id==$kont[$i]["ide"]){
                    $kont[$i]['adet'] = $adet;
                    $_SESSION['urunler'] = $kont;
                    $index = $i;
                }
            }            
            echo json_encode($kont[$index]);
        break;
    }
}





// echo json_encode($_SESSION['urunler']);
// $session = $_SESSION['urunler'];

//  for ($i=0; $i < count($_SESSION['urunler']); $i++) { 
//   $sql = $database->query("Select * from urunler Where ide = :ide", array("ide" => $session[$i]['ide']));
//   echo json_encode($sql); echo "<br>";
//  }


?>